# object detection bus dataset > 2024-12-01 5:49am
https://universe.roboflow.com/maria-4iqc2/object-detection-bus-dataset

Provided by a Roboflow user
License: CC BY 4.0

